<?php

if(file_exists('nql.madeline')){
	require 'vendor/autoload.php';
	$MadelineProto = new \danog\MadelineProto\API('nql.madeline');
	$user = readline('Enter username : @');
	$i = 0;
} else {
	if (!file_exists('madeline.php')) {
    copy('https://phar.madelineproto.xyz/madeline.php', 'madeline.php');
	}
	include 'madeline.php';
	$settings['app_info']['api_id'] = 210897;
	$settings['app_info']['api_hash'] = 'c7d2d161d83ce18d56c1a8a54437f5ff';
	$MadelineProto = new \danog\MadelineProto\API('nql.madeline', $settings);
	$MadelineProto->start();
	echo "\n\n\n Run turbo again !";
	exit;
}
while(true){
    $get = file_get_contents('https://t.me/'.$user,null,null,0,400);
    	preg_match("/(.*)(og:title)(.*)(content\=\")(.*)(\">)/i", $get,$name);
    	$name = $name[5];
    	if(preg_match("/^Telegram\: Contact.*/", $name)){
    		$MadelineProto->account->updateUsername(['username' => $user]);
    		unlink('nql.madeline');
    		exit;
    	}
    	echo '[ @'.$user.' ] : '.$i." -> " .date('s'). "\n";
    	$i++;
}