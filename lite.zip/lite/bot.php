<?php
include 'vendor/autoload.php';
$MadelineProto = new \danog\MadelineProto\API('../ss.madeline');
print_r($MadelineProto->method_call('users.getFullUser',['id'=>['_'=>'Vector<InputUser>']],['datacenter'=>1]));